GASTOS — PWA PARA IPHONE

1. Sube estos archivos a un alojamiento web que use HTTPS.
2. Abre la dirección desde Safari en el iPhone.
3. Pulsa Compartir → Añadir a pantalla de inicio.
4. La app funcionará como una aplicación independiente y guardará los gastos localmente en ese iPhone.

Nota: para que Safari permita la instalación como PWA, debe servirse por HTTPS (o desde localhost durante desarrollo).
